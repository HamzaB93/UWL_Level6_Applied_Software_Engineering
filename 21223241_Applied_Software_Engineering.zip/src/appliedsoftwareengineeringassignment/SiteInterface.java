package appliedsoftwareengineeringassignment;

public interface SiteInterface {
    // Methods to be implemented
    public int getSiteVisitors();
    
    public void setSitePopularity(String newSitePopularity);  
}
