package appliedsoftwareengineeringassignment;

public interface SaxonSystemInterface {
    // Methods that must be implemented    
    public String updateSitePopularity();  
    public void prioritiseSiteForMarketing(Site siteToPrioritise);
}
