package appliedsoftwareengineeringassignment;

import java.time.LocalDate;
import java.util.ArrayList;

public class SaxonSystem {

    //// Properties ////
    private ArrayList<Region> regions;
    private ArrayList<Site> sites;
    private ArrayList<Site> prioritsedSites;
    private LocalDate currentDate;
    
    // Will be used as a way of checking if the current data is 30th
    private LocalDate date = LocalDate.parse("2016-12-30");

        
    //// Constructor ////
    
    // Default, no need for parameterised
    public SaxonSystem() {
        regions = new ArrayList<Region>();
        sites = new ArrayList<Site>();
        prioritsedSites = new ArrayList<Site>();
        currentDate = LocalDate.parse("2016-12-30");
    }

    //// Getter ////
    
    // Return the currentDate
    public LocalDate getCurrentDate() {
        return currentDate;
    }    


    //// Setter ////
    // Set the currentDate to compare
    public void setCurrentDate(String d) {
        this.currentDate = currentDate.parse(d);
    }

    //// Add methods ////
    
    // Adding region objects
    public void addRegion(Region regionToAdd) {
        regions.add(regionToAdd);
    }

    // Adding site objects
    public void addSite(Site siteToAdd) {
        sites.add(siteToAdd);
    }

    // BUSINESS LOGIC - Add a site to priority
    public void addToPriorities(Site siteToAdd) {
        prioritsedSites.add(siteToAdd);
    }
    
    // USE CASE - Update the site popularity
    public String updateSitePopularity() {
        
        // If the currentDate is equal to date
        // Date will always be 30th December 2016
        if (currentDate.equals(date)) {
            // Define a Site
            Site s;
            
            // Loop through the sites list
            for (int i = 0; i < sites.size(); i++) {   
                // Get the details of current site and save it as Site s
                s = sites.get(i);
                
                // Get the number of visitors ad save them
                int visitors = s.getSiteVisitors();

                // IF the visitors are below 10000
                if (visitors < 10000) {
                    // Set rating to Bronze
                    s.setSitePopularity("Bronze");
                
                // If the visitors are between 10000 and 30000
                } else if (visitors >= 10000 && visitors < 30000) {
                    // Give Silver
                    s.setSitePopularity("Silver");
                    
                // Otherwise give it Gold    
                } else {
                    s.setSitePopularity("Gold");
                }
                
                // See if the site needs to be prioritised
                prioritiseSiteForMarketing(s);
            }
                // Give confirmation that sites have been updated
                return ("All site popularity ratings have been updated"
                    + "\n" + regions);
        
        // If the date wasn't correct, give a response         
        } else {
            return ("Cant Update Popularity yet. Wait till 30th Dec");
        }
    }

    // USE CASE - Identify if site needs marketing 
    public void prioritiseSiteForMarketing(Site siteToPrioritise){
        
        // If the sites' vistors are equal ore below 5000
        if(siteToPrioritise.getSiteVisitors() < 5000) {
            // Add it to a list
            prioritsedSites.add(siteToPrioritise);
        }     
    }
    
    //// toString ////
    
    // To print out the list of prioritised sites
    public String printPrioritisedSites() {
        return ("Sites that are now priorities\n" + prioritsedSites);
    }
    
    // To print out the object as string
    public String toString() {
        return "Saxon System\nRegion Details:\n" + regions;
    }
}
